﻿using System;
using System.Collections.Generic;

namespace W2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<GateInputs> gateInputs = new List<GateInputs>();
            var truthTable = gateInputs;
            truthTable.Add(new GateInputs { X = false, Y = false });
            truthTable.Add(new GateInputs { X = false, Y = true });
            truthTable.Add(new GateInputs { X = true, Y = false });
            truthTable.Add(new GateInputs { X = true, Y = true });

            Console.WriteLine($"X Y | Z");
            Console.WriteLine($"________ ");
            foreach (var row in truthTable)
            {
                var result = AndGates.InPut(row.X, row.Y);
                //Console.WriteLine($"The result of AndGate for inputs:" +
                //    $" X = {row.X} and Y = {row.Y} and the result = {result}");
                var xas = row.X ? "1" : "0";
                var yas = row.Y ? "1" : "0";
                var resultas = result ? "1" : "0";
                Console.WriteLine($"{xas} {yas} | {resultas}");
            }


            static void Test1()
            {
                var x = false;
                var y = false;
                var result = AndGates.InPut(x, y);
                Console.WriteLine(value: $"The result of AndGate for inputs:" +
                    $" X = {x} and Y = {y} and the result = {result}");
            }
        }
    }
}