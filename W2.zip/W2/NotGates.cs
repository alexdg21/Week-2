﻿using System;
namespace W2
{
    public class NotGates
    {
        public static bool InPut(bool x)
        {
            return !x;
        }
    }
}
